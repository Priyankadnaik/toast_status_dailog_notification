package com.example.user.toast;

import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import javax.xml.transform.Result;

public class MainActivity extends AppCompatActivity {
    Button b1,b2,b3;
    NotificationCompat.Builder notification;
    PendingIntent pendingIntent;
    NotificationManager manager;
    Intent resultIntent;
    TaskStackBuilder stackBuilder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         b1 = (Button)findViewById(R.id.button);
         b2=(Button) findViewById(R.id.button2);
         b2.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 String ns=Context.NOTIFICATION_SERVICE;
                 Intent notificationIntent=new Intent();
                 PendingIntent contentIntent=PendingIntent.getActivity(MainActivity.this,0,notificationIntent,0);
                 NotificationManager notificationManager=(NotificationManager)getSystemService(ns);
                 Notification notification=new Notification.Builder(MainActivity.this)
                         .setTicker("Message")
                         .setContentTitle("new message")
                         .setContentText("hello!you have a new message")
                         .setSmallIcon(R.drawable.star)
                         .setContentIntent(contentIntent).getNotification();
                 notification.flags=Notification.FLAG_AUTO_CANCEL;
                 notificationManager.notify(0,notification);


             }

         });

        // Show toast message when button is clicked
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"This is my toast message",Toast.LENGTH_LONG).show();// Set your own toast  message
            }
        });

    }
   /* protected void startNotification(){
        notification=new NotificationCompat.Builder(MainActivity.this).setContentTitle("Learn to crack updates").setContentText("new post notification").setTicker("new message alert!");
        notification.setSmallIcon(R.drawable.star);
        stackBuilder=TaskStackBuilder.create(MainActivity.this);
        stackBuilder.addParentStack(Result.class);
        resultIntent=new Intent(MainActivity.this,Result.class);
        stackBuilder.addNextIntent(resultIntent);
        pendingIntent=stackBuilder.getPendingIntent(0,PendingIntent.FLAG_UPDATE_CURRENT);
        notification.setContentIntent(pendingIntent);
        manager=(NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(0,notification.build());*/





    public void open(View view){
        b3=(Button) findViewById(R.id.button3);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("are you sure you wanted to make decision");
        alertDialogBuilder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainActivity.this,"you clicked yes button",Toast.LENGTH_LONG).show();
            }
        });
        alertDialogBuilder.setNegativeButton("no", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        AlertDialog alertDialog= alertDialogBuilder.create();
        alertDialog.show();
    }

   /* @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);*/
    }



